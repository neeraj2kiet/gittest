const Product=(props)=>{
    return (
        <>
        <tr>
            <td>{props.item.ID}</td>
            <td>{props.item.ProductName}</td>
            <td>{props.item.Quantity}</td>
            <td>{props.item.Price}</td>
        </tr>
        </>
    )
}

export default Product