const About=()=>{
    return (
        <>
          <h3>About: This application provides information about the products</h3>
        </>
    )
}
export default About;