import React from 'react'
import {Link,Outlet} from 'react-router-dom'



const Layout=()=>{
    return (
       <div>
        <span  style={{display:"inlineBlock",margin:"10px"}} ><Link to="/about">About</Link></span>
        <span style={{display:"inlineBlock",margin:"10px"}} ><Link to="/product">Product</Link></span>
        <Outlet/>
       </div>
        )
}

export default Layout