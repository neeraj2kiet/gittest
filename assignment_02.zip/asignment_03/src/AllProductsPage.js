import {useEffect, useState} from 'react'
import data from './data.json'
import { ProductList } from './ProductsList'
export const AllProductsPage=()=>{
     const [prodata,setProdata]=useState({})
     console.log(data)
     useEffect(()=>{
         setProdata(data)

     },[prodata])
     return (
        <>
        <ProductList data={data}/>

        </>
     )
}