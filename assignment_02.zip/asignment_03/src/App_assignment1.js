import { useState } from "react";

function App() {
  const [counter,setCounter]=useState(0)
  return (
    <>
    <h1>Counter Demo</h1>
    <p>Counter {counter}</p>
    <button onClick={()=>setCounter((prev)=>prev + 1)}>Increment Counter</button>
    <button onClick={()=>setCounter((prev)=>prev - 1)}>Decrement Counter</button>
    </>
  );
}

export default App;
