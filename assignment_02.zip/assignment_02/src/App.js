import { AllProductsPage } from "./AllProductsPage";

function App() {
 
  return (
    <>
    <AllProductsPage/>
    </>
  );
}

export default App;
