import Product from "./Product"
export const ProductList=(props)=>{
    if(!props.data){
        return;
    }
    return (
        <>
        <h1>Product List</h1>
        <table>
        <tr>
        <th>ID</th>
        <th>Product Name</th>
        <th>Quantity</th>
        <th>Price</th>
        </tr>
        {props.data.map((item)=>{
           return <Product key={item.ID} item={item}/>
        })}
        </table>

        </>
    )
}