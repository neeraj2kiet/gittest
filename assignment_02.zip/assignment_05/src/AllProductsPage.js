import {useEffect, useState} from 'react'
//import data from './data.json'
import { ProductList } from './ProductsList'
export const AllProductsPage=()=>{
   const [data, setData]=useState(null)
   const getData=async ()=>{
      const data=await fetch("http://localhost:3001/product");
      const jsondata=await data.json()
      setData(jsondata)
      console.log(jsondata)
  }
   
     useEffect(()=>{
         getData()

     },[data])
     return (
        <>
        <ProductList data={data}/>

        </>
     )
}