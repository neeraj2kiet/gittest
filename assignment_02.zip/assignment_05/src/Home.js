import React from 'react'
import {NavLink,Outlet} from 'react-router-dom'



const Layout=()=>{
    return (
       <div>
        <span  style={{display:"inlineBlock",margin:"10px"}} ><NavLink activeClassName="active" to="/about">About</NavLink></span>
        <span style={{display:"inlineBlock",margin:"10px"}} ><NavLink activeClassName="active" to="/product">Product</NavLink></span>
        <Outlet/>
       </div>
        )
}

export default Layout