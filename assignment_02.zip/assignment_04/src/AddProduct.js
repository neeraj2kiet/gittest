import React from 'react'
import { useNavigate } from 'react-router-dom';
import {useFormik} from 'formik';
import { addProductSchema } from './schemas';

const AddProduct=()=>{
//const StyleForm={height:'30px', width:"500px"}
const navigate=useNavigate();
const styleInput={display:"inline-block",width:"300px",height:"30px",padding:"5px",margin:"10px"}
const initialValues= {
    productname:"",
    quantity:"",
    price:"",
}
const {values, touched, errors, handleBlur, handleChange, handleSubmit}=useFormik({
        initialValues: initialValues,
        validationSchema: addProductSchema,
        onSubmit: async (values,action) => {
            console.log(values);
            //action.resetForm();
            const postData=await fetch("http://localhost:3001/allproducts",{
                method: 'post',
                headers:{
                'accept':'application/json',
                'content-type': 'application/json'
                },
                body: JSON.stringify(values)

            });
            const content = await postData.json();
            console.log(content)
            navigate("/products")
            
       },
       
    });
    return (
        <>
        <h2>Add Product</h2>
        <form onSubmit={handleSubmit}>
            <div>
                <input style={styleInput} type="text" onChange={handleChange} onBlur={handleBlur} name="productname" value={values.productname} placeholder='Enter Product Name'/>
                {errors.productname && touched.productname ? (<span style={{color:'red'}}>{errors.productname}</span>):null}
            </div>
            <div>
                <input style={styleInput} type="number" name="quantity"onChange={handleChange} onBlur={handleBlur} value={values.quantity} placeholder='Enter Quantity'/>
                {errors.quantity && touched.quantity ? <span style={{color:'red'}}>{errors.quantity}</span>:null }
            </div>
            <div>
                <input style={styleInput} type="text" name="price" onChange={handleChange} onBlur={handleBlur} value={values.price} placeholder='Enter Price' />
                {errors.price && touched.price ? <span style={{color:'red'}}>{errors.price}</span> : null}
            </div>
            <div style={{padding:'5px',margin:"10px"}}><input type="submit"/></div>
        </form>
        </>
    )
}

export default AddProduct ;
