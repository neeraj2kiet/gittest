import *  as Yup from "yup";

export const addProductSchema= Yup.object({
    productname:Yup.string().min(2).max(15).required("Product Name is required"),
    quantity:Yup.number().min(10).max(100000).required("Quantity is required"),
    price: Yup.string().min(2).max(6).required("Price is required")
})

