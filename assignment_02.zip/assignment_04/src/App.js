import { BrowserRouter,Routes, Route } from "react-router-dom"
import Layout from './Home'
import About from './About'
import { AllProductsPage } from "./AllProductsPage";
import AddProduct from './AddProduct';
import ProductDetails from  './ProductDetails';
import { createContext, useEffect,useState } from "react";
//import productdata from './db.json'
// import NewComponent from "./Newcomponent";
export const ProductsContext = createContext();

function App() { 
  const [productdata, setProductData]= useState(null)
  const getData=async ()=>{
    const data=await fetch("http://localhost:3001/allproducts");
    const jsondata=await data.json()
    setProductData(jsondata)
    console.log(jsondata)
}

useEffect(()=>{
     getData();

},[productdata])
  return (
    <div>
      <BrowserRouter>
      <ProductsContext.Provider value={productdata}>
    <Routes>
      <Route path="/" element={<Layout/>}>
      <Route index element={<About />} />
      <Route path="/about" element={<About />} />
      <Route path="/products" element={<AllProductsPage/>} />
      <Route path="/addproduct" element={<AddProduct/>} />
      <Route path="products/:prodname" element={<ProductDetails/>} />
      {/* <Route path="/newcomponent" element={<NewComponent/>} /> */}
      </Route>
     
    </Routes>
    </ProductsContext.Provider>
    </BrowserRouter>
    </div>
  );
}

export default App;
//export {data};
