import {useNavigate } from "react-router-dom"
const Product=(props)=>{
    const navigate= useNavigate();
const handler=()=>{
    if(window.confirm("Are you sure you want to view the details")){
    navigate("/products/" + props.item.productname )
    }else{
        navigate("/products")
    }

}

    return (
        <>
        <tr>
            {/* <td onClick={handler}><Link to={props.item.productname}>{props.item.productname}</Link></td> */}
            <td onClick={handler}><span style={{cursor:"pointer"}}>{props.item.productname}</span></td>
            <td>{props.item.quantity}</td>
            <td>{props.item.price}</td>
        </tr>
        </>
    )
}

export default Product