import { Link, useParams } from "react-router-dom";
const ProductDetails=()=>{
    const params= useParams();
    console.log(params);
    return (
        <>
         <h2>Product Details</h2>
         Product Name : <span>{params.prodname}</span>
         <p><Link to="/products">Back</Link></p>
        </>
    )
}

export default ProductDetails;