// import {useEffect, useState} from 'react'
//import data from './db.json'
import { ProductList } from './ProductsList'
import { Link } from 'react-router-dom'

export const AllProductsPage=()=>{
    //  const [prodata,setProdata]=useState({})
     
    //  useEffect(()=>{
    //      setProdata(data)

    //  },[prodata])
     return (
        <>
        {/* <ProductList data={data}/> */}
        <ProductList />
        <Link to ="/addproduct" >Add Product </Link>
        </>
     )
}