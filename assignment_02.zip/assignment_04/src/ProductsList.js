import { useContext } from "react"
import { ProductsContext } from "./App";
import Product from "./Product"
//import {data} from './App';
export const ProductList=()=>{
    //const {data}=props;
    //console.log(data)
    const data=useContext(ProductsContext);
    console.log(data)
    if(!data){
        return;
    }
    return (
        <>
        <h1>Product List</h1>
        <table>
            <thead>
        <tr>
        <th>Product Name</th>
        <th>Quantity</th>
        <th>Price</th>
        </tr>
        </thead>
        <tbody>
        {data.map((item)=>{

           return <Product key={item.id} item={item}/>
        })}
        </tbody>
        </table>

        </>
    )
}